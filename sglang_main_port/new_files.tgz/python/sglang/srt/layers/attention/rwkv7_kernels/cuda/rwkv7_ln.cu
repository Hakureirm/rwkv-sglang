// RWKV-7 x sglang fused norm-boundary kernels (W1' / ADR-0005 follow-on).
//
// Two ops, both pure same-math fusions of the layer's norm boundaries (the
// large-batch decode profile vs vllm-rwkv PR#8 found ~15 stock torch kernels
// of per-layer "glue" vs their 6 hand-fused ops; GEMM and WKV are excluded):
//
//   add_ln:      x_new = x + delta (fp16 residual add), y = LayerNorm(x_new).
//                Replaces the (add kernel + vectorized LN kernel) pair at the
//                pre-attn / pre-ffn / final-norm boundaries; x_new is written
//                once and the LN row stats are computed from registers.
//
//   gn_gatecorr: y = (GroupNorm(o) + (r*k*r_k).sum(-1,keepdim)*v) * g.
//                Replaces torch GroupNorm's RowwiseMoments + 1d-forward pair
//                PLUS the Triton _gate_corr kernel (their tmix_lnx_rkvres_xg
//                analog), dropping the o_norm HBM round-trip.
//
// GREEDY-EXACTNESS (the same bar every other fused kernel in this tree meets):
// both ops replicate their reference BIT-FOR-BIT, which for norms means
// replicating the REDUCTION ALGORITHM, not just the math:
//
//   * add_ln transcribes torch's vectorized_layer_norm_kernel (pytorch v2.11
//     aten/src/ATen/native/cuda/layer_norm_kernel.cu): one block of
//     (warp_size x 4) threads per row, aligned_vector<half,4> loads, the
//     WelfordDataLN online sum with reciprocal-multiply (delta * (1/new_count)),
//     the intra-warp shfl_down(16..1) cuWelfordCombine tree, the smem
//     inter-warp tree, sigma2/N at the end, rsqrtf, and the fp32 affine apply
//     with one final round to fp16. The residual add is done in fp32 and
//     rounded to fp16 BEFORE the stats (bit-identical to torch's a+b add
//     kernel: float add of two halves is exact, one rn round), so the stats
//     see exactly the tensor torch's LN would have seen.
//   * gn_gatecorr transcribes torch's RowwiseMomentsCUDAKernel for the 1d
//     GroupNorm case (group_norm_kernel.cu; D=head_dim < 512 -> one 32-thread
//     warp per (token, head), WelfordOps with true division + int64 n, the
//     WarpReduce shfl_down(16..1) combine with zero-count guards), including
//     two torch quirks that matter for bits: eps is rounded through fp16
//     (GroupNormKernelImpl casts the double eps to scalar_t=half), and
//     mean/rstd pass through the fp16 mean/rstd TENSORS between the moments
//     and apply kernels (we round them through fp16 in registers). The
//     gate-correction epilogue then replicates the deployed Triton
//     _gate_corr kernel's rounding sequence (fused.py): every binary op
//     computes in fp32 and rounds to fp16 before the next, and the 64-wide
//     (r*k*r_k) reduction uses the exact summation tree the Triton kernel
//     lowers to (butterfly-xor within each 32-lane half, halves added; probed
//     bit-for-bit against the live kernel before enabling - see
//     bench/test_ln_fused.py).
//
// FMA NOTE: the LN/GN APPLY expressions are written exactly like the aten
// sources and compiled with default -O3 (fmad on), reproducing the
// contraction pattern of the torch build; the fp16-rounded epilogue chains
// cannot contract across the explicit __float2half_rn round-trips. The gates
// in bench/test_ln_fused.py compare against the live torch/Triton ops on
// randomized + adversarial inputs and must show ZERO differing bytes before
// either op is enabled (RWKV_FUSED_ADDLN / RWKV_FUSED_GNGC, default OFF).
//
// cuda-graph safe: static shapes, current stream, no host sync, allocations
// only for the outputs. Decode + extend both eligible (shape-agnostic in T).

#include <ATen/ATen.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>
#include <torch/library.h>
#include <cuda_fp16.h>

#include <cstdlib>
#include <optional>
#include <tuple>

#include "rwkv7_pdl.cuh"  // PDL chain (task #50 sm120 step); no-op unarmed

using dtype = at::Half;

namespace {

constexpr int kVec = 4;  // torch ln vec_size (dtype-independent, see aten)

struct alignas(sizeof(__half) * kVec) half4 {
  __half val[kVec];
};

// ---- torch vectorized-LN Welford (WelfordDataLN, float count) ----
struct WelfordLN {
  float mean;
  float sigma2;
  float count;
};

__device__ __forceinline__ WelfordLN welford_ln_onlinesum(const float val,
                                                          const WelfordLN& c) {
  float delta = val - c.mean;
  float new_count = c.count + 1.f;
  float new_mean = c.mean + delta * (1.f / new_count);  // aten: reciprocal mult
  return {new_mean, c.sigma2 + delta * (val - new_mean), new_count};
}

__device__ __forceinline__ WelfordLN welford_ln_combine(const WelfordLN dataB,
                                                        const WelfordLN dataA) {
  // transcribed verbatim from aten cuWelfordCombine (arg order dataB, dataA!)
  float delta = dataB.mean - dataA.mean;
  float count = dataA.count + dataB.count;
  float mean, sigma2;
  if (count > 0.f) {
    float coef = 1.f / count;
    float nA = dataA.count * coef;
    float nB = dataB.count * coef;
    mean = nA * dataA.mean + nB * dataB.mean;
    sigma2 = dataA.sigma2 + dataB.sigma2 + delta * delta * dataA.count * nB;
  } else {
    mean = 0.f;
    sigma2 = 0.f;
  }
  return {mean, sigma2, count};
}

// compute_stats over the fp16 row held in registers (vals[n_own] = this
// thread's vec chunks, chunk i covers row vecs thrx, thrx+numx, ...), matching
// aten's per-thread order + warp/block trees. blockDim must be (32, NW).
template <int MaxVecPerThread>
__device__ WelfordLN ln_compute_stats(const half4* vals, int n_own, int N,
                                      float* buf) {
  WelfordLN wd{0.f, 0.f, 0.f};
  for (int i = 0; i < n_own; ++i) {
#pragma unroll
    for (int ii = 0; ii < kVec; ii++) {
      wd = welford_ln_onlinesum(__half2float(vals[i].val[ii]), wd);
    }
  }
  // intra-warp reduction (shfl_down 16..1), combine(current, shuffled)
  for (int offset = 16; offset > 0; offset >>= 1) {
    WelfordLN wdB{__shfl_down_sync(0xffffffff, wd.mean, offset),
                  __shfl_down_sync(0xffffffff, wd.sigma2, offset),
                  __shfl_down_sync(0xffffffff, wd.count, offset)};
    wd = welford_ln_combine(wd, wdB);
  }
  // inter-warp tree via smem (transcribed; blockDim.y power of two)
  if (blockDim.y > 1) {
    float* meansigmabuf = buf;
    float* countbuf = buf + blockDim.y;
    for (int offset = blockDim.y / 2; offset > 0; offset /= 2) {
      if (threadIdx.x == 0 && threadIdx.y >= offset && threadIdx.y < 2 * offset) {
        const int wrt_y = threadIdx.y - offset;
        meansigmabuf[2 * wrt_y] = wd.mean;
        meansigmabuf[2 * wrt_y + 1] = wd.sigma2;
        countbuf[wrt_y] = wd.count;
      }
      __syncthreads();
      if (threadIdx.x == 0 && threadIdx.y < offset) {
        WelfordLN wdB{meansigmabuf[2 * threadIdx.y],
                      meansigmabuf[2 * threadIdx.y + 1], countbuf[threadIdx.y]};
        wd = welford_ln_combine(wd, wdB);
      }
      __syncthreads();
    }
    if (threadIdx.x == 0 && threadIdx.y == 0) {
      meansigmabuf[0] = wd.mean;
      meansigmabuf[1] = wd.sigma2 / float(N);
    }
    __syncthreads();
    return WelfordLN{meansigmabuf[0], meansigmabuf[1], 0.f};
  } else {
    return WelfordLN{__shfl_sync(0xffffffff, wd.mean, 0),
                     __shfl_sync(0xffffffff, wd.sigma2, 0) / float(N), 0.f};
  }
}

// x_new = round_fp16(x + delta); y = LayerNorm(x_new) — torch bit order.
// One block per row, blockDim (32, 4); N % 4 == 0; N <= MaxVecPerThread*128*4.
template <int MaxVecPerThread>
__global__ void add_ln_kernel(int N, float eps,
                              const dtype* __restrict__ x,
                              const dtype* __restrict__ delta,
                              const dtype* __restrict__ gamma,
                              const dtype* __restrict__ beta,
                              dtype* __restrict__ x_new,
                              dtype* __restrict__ y) {
  extern __shared__ float s_data[];
  const int64_t i1 = blockIdx.x;
  const half4* xv = reinterpret_cast<const half4*>(x + i1 * N);
  const half4* dv = reinterpret_cast<const half4*>(delta + i1 * N);
  const half4* gv = reinterpret_cast<const half4*>(gamma);
  const half4* bv = reinterpret_cast<const half4*>(beta);
  half4* xnv = reinterpret_cast<half4*>(x_new + i1 * N);
  half4* yv = reinterpret_cast<half4*>(y + i1 * N);

  const int numx = blockDim.x * blockDim.y;
  const int thrx = threadIdx.x + threadIdx.y * blockDim.x;
  const int n_vec = N / kVec;
  rwkv7_pdl_wait();  // x/delta from the predecessor block (no-op unarmed)

  // residual add: float add of two halves is EXACT; one rn round to fp16 ==
  // torch's elementwise add kernel. Keep this thread's x_new chunks in
  // registers (written once; stats + apply reuse the identical bits).
  half4 own[MaxVecPerThread];
  int n_own = 0;
  for (int i = thrx; i < n_vec; i += numx) {
    half4 a = xv[i];
    half4 b = dv[i];
    half4 s;
#pragma unroll
    for (int ii = 0; ii < kVec; ii++) {
      s.val[ii] =
          __float2half_rn(__half2float(a.val[ii]) + __half2float(b.val[ii]));
    }
    xnv[i] = s;
    own[n_own++] = s;
  }

  WelfordLN wd = ln_compute_stats<MaxVecPerThread>(own, n_own, N, s_data);
  float rstd_val = rsqrtf(wd.sigma2 + eps);

  // affine apply, aten expression (fp32 compute, one implicit round at store)
  int slot = 0;
  for (int i = thrx; i < n_vec; i += numx, ++slot) {
    half4 data = own[slot];
    half4 g4 = gv[i];
    half4 b4 = bv[i];
    half4 out;
#pragma unroll
    for (int ii = 0; ii < kVec; ii++) {
      out.val[ii] = __float2half_rn(
          __half2float(g4.val[ii]) *
              (rstd_val * (__half2float(data.val[ii]) - wd.mean)) +
          __half2float(b4.val[ii]));
    }
    yv[i] = out;
  }
  rwkv7_pdl_launch_dependents();  // shift_lerp stage schedules early
}

// F0066 (Stage-B fusion round 2): fused (residual add + LayerNorm + paged
// token-shift + J-way lerp) — one launch replacing the add_ln -> shift_lerpJ
// pair at both per-layer norm boundaries. BYTE-EXACT COMPOSITION: the
// add/stats/apply phases are add_ln_kernel's WIDE config verbatim (same
// (32,16) partition, same Welford trees => bit-identical y in registers), and
// the shift/lerp phase replicates shift_lerp*_kernel's exact rounding chain
// (sh = round_fp16(conv) read BEFORE the scatter; conv <- float(y_fp16);
// d = round_fp16(sh - y); out_j = round_fp16(y + round_fp16(mix_j * d))) on
// the register-resident y. `normed` never touches HBM (the composition wrote
// 8KB + re-read it twice); gated by bench/test_addln_shift.py: torch.equal on
// (x_new, out, conv-after) vs the two-op composition, pads included.
// PAD rows (ci<0 or >=S): x_new/stats still computed + written (composition
// parity — add_ln has no pad concept), out rows zeroed, conv untouched.
template <int MaxVecPerThread, int J>
__global__ void add_ln_shift_kernel(
    int N, float eps, int S,
    const dtype* __restrict__ x,
    const dtype* __restrict__ delta,
    const dtype* __restrict__ gamma,
    const dtype* __restrict__ beta,
    const dtype* __restrict__ mixes,        // [J, N] fp16
    const int* __restrict__ cache_indices,  // [T]
    float* __restrict__ conv,               // [S, N] fp32, row stride N
    dtype* __restrict__ x_new,              // [T, N]
    dtype* __restrict__ out) {              // [J, T, N]
  extern __shared__ float s_data[];
  const int64_t i1 = blockIdx.x;
  const int64_t T = gridDim.x;
  const half4* xv = reinterpret_cast<const half4*>(x + i1 * N);
  const half4* dv = reinterpret_cast<const half4*>(delta + i1 * N);
  const half4* gv = reinterpret_cast<const half4*>(gamma);
  const half4* bv = reinterpret_cast<const half4*>(beta);
  half4* xnv = reinterpret_cast<half4*>(x_new + i1 * N);
  const int numx = blockDim.x * blockDim.y;
  const int thrx = threadIdx.x + threadIdx.y * blockDim.x;
  const int n_vec = N / kVec;
  rwkv7_pdl_wait();  // x/delta from the predecessor block (no-op unarmed)
  half4 own[MaxVecPerThread];
  int n_own = 0;
  for (int i = thrx; i < n_vec; i += numx) {
    half4 a = xv[i];
    half4 b = dv[i];
    half4 s;
#pragma unroll
    for (int ii = 0; ii < kVec; ii++) {
      s.val[ii] =
          __float2half_rn(__half2float(a.val[ii]) + __half2float(b.val[ii]));
    }
    xnv[i] = s;
    own[n_own++] = s;
  }
  WelfordLN wd = ln_compute_stats<MaxVecPerThread>(own, n_own, N, s_data);
  float rstd_val = rsqrtf(wd.sigma2 + eps);
  const int ci = cache_indices[i1];
  const bool padrow = (ci < 0 || ci >= S);
  float* cr = padrow ? nullptr : conv + static_cast<int64_t>(ci) * N;
  int slot = 0;
  for (int i = thrx; i < n_vec; i += numx, ++slot) {
    half4 data = own[slot];
    half4 g4 = gv[i];
    half4 b4 = bv[i];
#pragma unroll
    for (int ii = 0; ii < kVec; ii++) {
      const int k = i * kVec + ii;
      const int64_t obase = i1 * N + k;
      if (padrow) {
#pragma unroll
        for (int j = 0; j < J; ++j) {
          out[static_cast<int64_t>(j) * T * N + obase] = __float2half_rn(0.f);
        }
        continue;
      }
      // add_ln apply expression verbatim -> the fp16 y the composition stored
      const __half yh = __float2half_rn(
          __half2float(g4.val[ii]) *
              (rstd_val * (__half2float(data.val[ii]) - wd.mean)) +
          __half2float(b4.val[ii]));
      const float y_f = __half2float(yh);            // shift's f32(normed_fp16)
      const float sh = __half2float(__float2half_rn(cr[k]));  // prev BEFORE scatter
      cr[k] = y_f;                                   // conv <- float(normed)
      const float d = __half2float(__float2half_rn(sh - y_f));
#pragma unroll
      for (int j = 0; j < J; ++j) {
        const float m = static_cast<float>(mixes[static_cast<int64_t>(j) * N + k]);
        const float prod = __half2float(__float2half_rn(m * d));
        out[static_cast<int64_t>(j) * T * N + obase] = __float2half_rn(y_f + prod);
      }
    }
  }
  rwkv7_pdl_launch_dependents();  // r/k/v (J=6) or ffn.key (J=1) GEMV schedules early
}

// ---- torch GroupNorm RowwiseMoments Welford (WelfordOps: true division) ----
struct WelfordGN {
  float mean;
  float m2;
  long long n;
  float nf;
};

__device__ __forceinline__ WelfordGN welford_gn_reduce(WelfordGN acc, float data) {
  long long new_n = acc.n + 1;
  float new_nf = static_cast<float>(new_n);
  float delta = data - acc.mean;
  float new_mean = acc.mean + delta / new_nf;  // true fdiv (aten WelfordOps)
  float new_delta = data - new_mean;
  return {new_mean, acc.m2 + delta * new_delta, new_n, new_nf};
}

__device__ __forceinline__ WelfordGN welford_gn_combine(WelfordGN a, WelfordGN b) {
  if (a.nf == 0.f) return b;
  if (b.nf == 0.f) return a;
  float delta = b.mean - a.mean;
  float new_count = a.nf + b.nf;
  float nb_over_n = b.nf / new_count;  // true fdiv
  return {a.mean + delta * nb_over_n,
          a.m2 + b.m2 + delta * delta * a.nf * nb_over_n, -1, new_count};
}

// The deployed Triton _gate_corr kernel's 64-wide fp32 sum lowers to a
// butterfly-xor tree within each 32-lane half of the axis, the two half-sums
// added low+high. Probed bit-for-bit against the live kernel (BK=64,
// num_warps=4, triton 3.6) by bench/test_ln_fused.py BEFORE enabling; if that
// probe ever fails on a new stack the op stays disabled (gate, not hope).
// Here thread t of the 32-thread warp holds a=p2[t] (low half) and b=p2[t+32]
// (high half).
__device__ __forceinline__ float gate_corr_sum64(float a, float b) {
  for (int offset = 16; offset > 0; offset >>= 1) {
    a += __shfl_xor_sync(0xffffffff, a, offset);
    b += __shfl_xor_sync(0xffffffff, b, offset);
  }
  return a + b;  // low half + high half
}

// y = (GroupNorm(o) + (r*k*r_k).sum(head)*v) * g, head_dim = D <= 512.
// One 32-thread block per (token, head); mirrors torch's 1d GroupNorm
// RowwiseMoments launch (num_threads = warp_size when D < 512).
__global__ void gn_gatecorr_kernel(int D, float eps /* fp16-rounded by host */,
                                   int NH,
                                   const dtype* __restrict__ o,
                                   const dtype* __restrict__ r,
                                   const dtype* __restrict__ k,
                                   const dtype* __restrict__ rk,  // [NH*D]
                                   const dtype* __restrict__ v,
                                   const dtype* __restrict__ g,
                                   const dtype* __restrict__ gamma,  // [NH*D]
                                   const dtype* __restrict__ beta,   // [NH*D]
                                   dtype* __restrict__ out) {
  const int64_t tg = blockIdx.x;   // t * NH + h
  const int h = static_cast<int>(tg % NH);
  const int64_t rowbase = tg * D;  // == (t*NH + h) * D = t*H + h*D
  const int64_t pbase = static_cast<int64_t>(h) * D;
  rwkv7_pdl_wait();  // o is the WKV stage's output (no-op unarmed)

  // --- RowwiseMoments over o[rowbase : rowbase+D] (torch order: j += 32) ---
  WelfordGN val{0.f, 0.f, 0, 0.f};
  for (int j = threadIdx.x; j < D; j += 32) {
    val = welford_gn_reduce(val, __half2float(o[rowbase + j]));
  }
  for (int offset = 16; offset > 0; offset >>= 1) {
    WelfordGN vb{__shfl_down_sync(0xffffffff, val.mean, offset),
                 __shfl_down_sync(0xffffffff, val.m2, offset),
                 __shfl_down_sync(0xffffffff, val.n, offset),
                 __shfl_down_sync(0xffffffff, val.nf, offset)};
    val = welford_gn_combine(val, vb);
  }
  // project on lane 0, then broadcast the HALF-ROUNDED mean/rstd (torch stores
  // them into fp16 tensors between its two kernels; correction=0 -> /nf).
  float mean_f, rstd_f;
  if (threadIdx.x == 0) {
    float var = val.m2 / val.nf;
    mean_f = __half2float(__float2half_rn(val.mean));
    rstd_f = __half2float(__float2half_rn(rsqrtf(var + eps)));
  }
  mean_f = __shfl_sync(0xffffffff, mean_f, 0);
  rstd_f = __shfl_sync(0xffffffff, rstd_f, 0);

  // --- apply + gate-corr epilogue for this thread's channels j, j+32 ---
  // GroupNorm1dForward: (x - mean) * rstd * gamma + beta, fp32, one round.
  // Then the Triton _gate_corr rounding chain (each op rounds to fp16).
  float p2f[2];
  __half onormh[2];
  int jj[2] = {static_cast<int>(threadIdx.x), static_cast<int>(threadIdx.x) + 32};
#pragma unroll
  for (int c = 0; c < 2; ++c) {
    const int j = jj[c];
    if (j < D) {
      const int64_t idx = rowbase + j;
      onormh[c] = __float2half_rn(
          (__half2float(o[idx]) - mean_f) * rstd_f *
              __half2float(gamma[pbase + j]) +
          __half2float(beta[pbase + j]));
      float rf = __half2float(r[idx]);
      float kf = __half2float(k[idx]);
      float rkf = __half2float(rk[pbase + j]);
      float p1 = __half2float(__float2half_rn(rf * kf));
      p2f[c] = __half2float(__float2half_rn(p1 * rkf));
    } else {
      onormh[c] = __float2half_rn(0.f);
      p2f[c] = 0.f;
    }
  }
  float s = gate_corr_sum64(p2f[0], p2f[1]);
  float s16 = __half2float(__float2half_rn(s));  // tl.sum(...).to(DT)
#pragma unroll
  for (int c = 0; c < 2; ++c) {
    const int j = jj[c];
    if (j < D) {
      const int64_t idx = rowbase + j;
      float gc = __half2float(__float2half_rn(s16 * __half2float(v[idx])));
      float oo = __half2float(__float2half_rn(__half2float(onormh[c]) + gc));
      out[idx] = __float2half_rn(oo * __half2float(g[idx]));
    }
  }
  rwkv7_pdl_launch_dependents();  // o_proj GEMV schedules early
}

// y = relu(x)^2 in ONE kernel (their `relu_square` analog). The reference is
// torch.relu(k) ** 2 on fp16: relu is exact (max(x,0), no rounding); pow2
// computes float(r)*float(r) and rounds once. Both reproduced verbatim; pure
// elementwise, so fusing the pair is bit-exact by construction (gated anyway
// by bench/test_ln_fused.py). Fires on the M>1 dense ffn path - the M==1
// path already has gemv_m1_sqrelu / sparse_cmix.
__global__ void relu_sq_kernel(int64_t n, const dtype* __restrict__ x,
                               dtype* __restrict__ y) {
  const int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
  if (i < n) {
    float v = __half2float(x[i]);
    float r = v > 0.f ? v : 0.f;
    y[i] = __float2half_rn(r * r);
  }
}

// Batched LoRA-output gate activations (their tmix_vres_gate analog), the
// M>4 sibling of fused.py's bsz1 _lora_gates_kernel: at large batch the LoRA
// chains run as cuBLAS GEMMs and their OUTER activations run as ~8 stock
// elementwise kernels per layer (3 sigmoids + neg/mul + sub/mul/add). One
// kernel computes, per element, the exact torch rounding chain the deployed
// path runs (each binary op fp32 -> rounded to fp16 before the next; sigmoid
// is torch's (half)(1.f/(1.f+expf(-(float)x))), the same form the project's
// bsz1 kernel byte-validated via bench/test_lora_gates.py):
//   w_log = rnd((-rnd(sigmoid(wl))) * inv_sqrt_e)
//   a     = rnd(sigmoid(al))
//   v_new = rnd(v + rnd(rnd(vf - v) * rnd(sigmoid(vl))))      [HAS_V only]
__global__ void vres_gates_kernel(int64_t n, bool has_v, float inv_sqrt_e,
                                  const dtype* __restrict__ wl,
                                  const dtype* __restrict__ al,
                                  const dtype* __restrict__ vl,
                                  const dtype* __restrict__ v,
                                  const dtype* __restrict__ vf,
                                  dtype* __restrict__ w_log,
                                  dtype* __restrict__ a_out,
                                  dtype* __restrict__ v_out) {
  const int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
  if (i >= n) return;
  const float s0 =
      __half2float(__float2half_rn(1.f / (1.f + expf(-__half2float(wl[i])))));
  w_log[i] = __float2half_rn((-s0) * inv_sqrt_e);
  a_out[i] = __float2half_rn(1.f / (1.f + expf(-__half2float(al[i]))));
  if (has_v) {
    const float s3 =
        __half2float(__float2half_rn(1.f / (1.f + expf(-__half2float(vl[i])))));
    const float vv = __half2float(v[i]);
    const float d = __half2float(__float2half_rn(__half2float(vf[i]) - vv));
    const float p = __half2float(__float2half_rn(d * s3));
    v_out[i] = __float2half_rn(vv + p);
  }
}

}  // namespace

std::tuple<at::Tensor, at::Tensor, at::Tensor> vres_gates(
    at::Tensor wl, at::Tensor al, std::optional<at::Tensor> vl_opt,
    at::Tensor v, std::optional<at::Tensor> vf_opt, double inv_sqrt_e) {
  const int64_t n = wl.numel();
  const bool has_v = vl_opt.has_value();
  TORCH_CHECK(wl.is_cuda() && wl.scalar_type() == at::kHalf && wl.is_contiguous(),
              "vres_gates: wl CUDA fp16 contiguous");
  TORCH_CHECK(al.scalar_type() == at::kHalf && al.numel() == n && al.is_contiguous(),
              "vres_gates: al fp16 same numel");
  TORCH_CHECK(v.scalar_type() == at::kHalf && v.numel() == n && v.is_contiguous(),
              "vres_gates: v fp16 same numel");
  if (has_v) {
    TORCH_CHECK(vl_opt->scalar_type() == at::kHalf && vl_opt->numel() == n &&
                    vl_opt->is_contiguous() && vf_opt.has_value() &&
                    vf_opt->scalar_type() == at::kHalf && vf_opt->numel() == n &&
                    vf_opt->is_contiguous(),
                "vres_gates: vl/vf fp16 same numel");
  }
  auto w_log = at::empty_like(wl);
  auto a_out = at::empty_like(wl);
  auto v_out = has_v ? at::empty_like(v) : v;
  if (n == 0) return {w_log, a_out, v_out};
  auto stream = at::cuda::getCurrentCUDAStream();
  const int threads = 256;
  const int64_t blocks = (n + threads - 1) / threads;
  vres_gates_kernel<<<static_cast<unsigned>(blocks), threads, 0, stream>>>(
      n, has_v, static_cast<float>(inv_sqrt_e), wl.data_ptr<dtype>(),
      al.data_ptr<dtype>(),
      has_v ? vl_opt->data_ptr<dtype>() : wl.data_ptr<dtype>(),
      v.data_ptr<dtype>(),
      has_v ? vf_opt->data_ptr<dtype>() : wl.data_ptr<dtype>(),
      w_log.data_ptr<dtype>(), a_out.data_ptr<dtype>(),
      has_v ? v_out.data_ptr<dtype>() : w_log.data_ptr<dtype>());
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  return {w_log, a_out, v_out};
}

at::Tensor relu_sq(at::Tensor x) {
  TORCH_CHECK(x.is_cuda() && x.scalar_type() == at::kHalf && x.is_contiguous(),
              "relu_sq: x CUDA fp16 contiguous");
  auto y = at::empty_like(x);
  const int64_t n = x.numel();
  if (n == 0) return y;
  auto stream = at::cuda::getCurrentCUDAStream();
  const int threads = 256;
  const int64_t blocks = (n + threads - 1) / threads;
  relu_sq_kernel<<<static_cast<unsigned>(blocks), threads, 0, stream>>>(
      n, x.data_ptr<dtype>(), y.data_ptr<dtype>());
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  return y;
}

// F0065 (Stage-B opener): the deployed (32,4) config transcribes torch's
// per-row block for BIT-PARITY — correct at the large-batch profile it was
// built against, but at decode bsz1 the launch is grid=dim3(T=1): ONE
// 128-thread block on the whole GPU, ~6.6 us/call x 64.5 calls/step = 426
// us/step of the 7.2B bsz1 BUSY (F0063 per-kernel table). Additionally
// own[16] is dynamically indexed -> local-memory spill risk at MaxVec=16.
// The WIDE variant (env RWKV_ADDLN_WIDE=1, small-T only) runs the SAME
// template at (32,16)=512 threads/row with MaxVecPerThread=2 (registers, no
// spill): 4x fewer serial load rounds per thread, same Welford ALGORITHM but
// a DIFFERENT partition/tree shape => NOT bit-parity with torch's (32,4)
// order. Numerics bar: fp32-reference oracle tolerance + greedy-EXACT e2e
// (the fp16-state WKV precedent), gated before any default flip; default
// remains the parity config.
static bool addln_wide_enabled() {
  static const bool v = []() {
    const char* e = getenv("RWKV_ADDLN_WIDE");
    return e && e[0] == '1';
  }();
  return v;
}

std::tuple<at::Tensor, at::Tensor> add_ln(at::Tensor x, at::Tensor delta,
                                          at::Tensor gamma, at::Tensor beta,
                                          double eps) {
  const int64_t T = x.size(0);
  const int64_t N = x.size(1);
  TORCH_CHECK(x.is_cuda() && x.scalar_type() == at::kHalf, "add_ln: x CUDA fp16");
  TORCH_CHECK(delta.scalar_type() == at::kHalf && delta.sizes() == x.sizes(),
              "add_ln: delta fp16 same shape");
  TORCH_CHECK(gamma.scalar_type() == at::kHalf && gamma.numel() == N &&
                  beta.scalar_type() == at::kHalf && beta.numel() == N,
              "add_ln: affine fp16 [N]");
  TORCH_CHECK(x.is_contiguous() && delta.is_contiguous() &&
                  gamma.is_contiguous() && beta.is_contiguous(),
              "add_ln: inputs contiguous");
  TORCH_CHECK(N % kVec == 0, "add_ln: N % 4 == 0 (torch vectorized-LN tier)");
  constexpr int kMaxVecPerThread = 16;  // N <= 16*128*4 = 8192
  TORCH_CHECK(N <= kMaxVecPerThread * 128 * kVec, "add_ln: N too large");
  auto x_new = at::empty_like(x);
  auto y = at::empty_like(x);
  if (T == 0) return {x_new, y};
  auto stream = at::cuda::getCurrentCUDAStream();
  const bool pdl = rwkv7_pdl_enabled("ln");
  // WIDE small-T path: (32,16) needs each thread to own <= 2 vecs => N <= 4096.
  if (addln_wide_enabled() && T <= 32 && N <= 2 * 512 * kVec) {
    const dim3 threads_w(32, 16, 1);
    const int nshared_w = threads_w.y * 3 / 2 * sizeof(float);
    rwkv7_launch_maybe_pdl(pdl, add_ln_kernel<2>,
        dim3(static_cast<unsigned>(T)), threads_w, nshared_w, stream.stream(),
        static_cast<int>(N), static_cast<float>(eps),
        static_cast<const dtype*>(x.data_ptr<dtype>()),
        static_cast<const dtype*>(delta.data_ptr<dtype>()),
        static_cast<const dtype*>(gamma.data_ptr<dtype>()),
        static_cast<const dtype*>(beta.data_ptr<dtype>()),
        x_new.data_ptr<dtype>(), y.data_ptr<dtype>());
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return {x_new, y};
  }
  const dim3 threads(32, 4, 1);
  const int nshared = threads.y > 1 ? threads.y * 3 / 2 * sizeof(float) : 0;
  rwkv7_launch_maybe_pdl(pdl, add_ln_kernel<kMaxVecPerThread>,
      dim3(static_cast<unsigned>(T)), threads, nshared, stream.stream(),
      static_cast<int>(N), static_cast<float>(eps),
      static_cast<const dtype*>(x.data_ptr<dtype>()),
      static_cast<const dtype*>(delta.data_ptr<dtype>()),
      static_cast<const dtype*>(gamma.data_ptr<dtype>()),
      static_cast<const dtype*>(beta.data_ptr<dtype>()),
      x_new.data_ptr<dtype>(), y.data_ptr<dtype>());
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  return {x_new, y};
}

// F0066 host: shared launcher for J=6 (attn entry) and J=1 (ffn entry).
// WIDE-tier only ((32,16), MaxVec=2 => N<=4096); the Python wrapper falls back
// to the two-op path when ineligible, so these are hard checks, not dispatch.
std::tuple<at::Tensor, at::Tensor> add_ln_shift_impl(
    at::Tensor x, at::Tensor delta, at::Tensor gamma, at::Tensor beta,
    double eps, at::Tensor mixes, at::Tensor cache_indices, at::Tensor conv,
    int64_t J) {
  const int64_t T = x.size(0);
  const int64_t N = x.size(1);
  TORCH_CHECK(x.is_cuda() && x.scalar_type() == at::kHalf, "add_ln_shift: x CUDA fp16");
  TORCH_CHECK(delta.scalar_type() == at::kHalf && delta.sizes() == x.sizes(),
              "add_ln_shift: delta fp16 same shape");
  TORCH_CHECK(gamma.scalar_type() == at::kHalf && gamma.numel() == N &&
                  beta.scalar_type() == at::kHalf && beta.numel() == N,
              "add_ln_shift: affine fp16 [N]");
  TORCH_CHECK(mixes.scalar_type() == at::kHalf && mixes.numel() == J * N,
              "add_ln_shift: mixes fp16 [J,N]");
  TORCH_CHECK(conv.scalar_type() == at::kFloat && conv.is_contiguous() &&
                  conv.dim() >= 2 && conv.size(1) == N,
              "add_ln_shift: conv fp32 [S,N,1] contiguous, hidden==N");
  TORCH_CHECK(cache_indices.scalar_type() == at::kInt &&
                  cache_indices.size(0) == T,
              "add_ln_shift: cache_indices int32 [T]");
  TORCH_CHECK(x.is_contiguous() && delta.is_contiguous() &&
                  gamma.is_contiguous() && beta.is_contiguous() &&
                  mixes.is_contiguous() && cache_indices.is_contiguous(),
              "add_ln_shift: inputs contiguous");
  TORCH_CHECK(N % kVec == 0 && N <= 2 * 512 * kVec,
              "add_ln_shift: N%4==0 and N<=4096 (WIDE tier)");
  auto x_new = at::empty_like(x);
  auto out = at::empty({J, T, N}, x.options());
  if (T == 0) return {x_new, out};
  auto stream = at::cuda::getCurrentCUDAStream();
  const bool pdl = rwkv7_pdl_enabled("ln");
  const dim3 threads_w(32, 16, 1);
  const int nshared_w = threads_w.y * 3 / 2 * sizeof(float);
  if (J == 6) {
    rwkv7_launch_maybe_pdl(pdl, add_ln_shift_kernel<2, 6>,
        dim3(static_cast<unsigned>(T)), threads_w, nshared_w, stream.stream(),
        static_cast<int>(N), static_cast<float>(eps),
        static_cast<int>(conv.size(0)),
        static_cast<const dtype*>(x.data_ptr<dtype>()),
        static_cast<const dtype*>(delta.data_ptr<dtype>()),
        static_cast<const dtype*>(gamma.data_ptr<dtype>()),
        static_cast<const dtype*>(beta.data_ptr<dtype>()),
        static_cast<const dtype*>(mixes.data_ptr<dtype>()),
        static_cast<const int*>(cache_indices.data_ptr<int>()),
        conv.data_ptr<float>(), x_new.data_ptr<dtype>(),
        out.data_ptr<dtype>());
  } else {
    TORCH_CHECK(J == 1, "add_ln_shift: J must be 6 or 1");
    rwkv7_launch_maybe_pdl(pdl, add_ln_shift_kernel<2, 1>,
        dim3(static_cast<unsigned>(T)), threads_w, nshared_w, stream.stream(),
        static_cast<int>(N), static_cast<float>(eps),
        static_cast<int>(conv.size(0)),
        static_cast<const dtype*>(x.data_ptr<dtype>()),
        static_cast<const dtype*>(delta.data_ptr<dtype>()),
        static_cast<const dtype*>(gamma.data_ptr<dtype>()),
        static_cast<const dtype*>(beta.data_ptr<dtype>()),
        static_cast<const dtype*>(mixes.data_ptr<dtype>()),
        static_cast<const int*>(cache_indices.data_ptr<int>()),
        conv.data_ptr<float>(), x_new.data_ptr<dtype>(),
        out.data_ptr<dtype>());
  }
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  return {x_new, out};
}

std::tuple<at::Tensor, at::Tensor> add_ln_shift6(
    at::Tensor x, at::Tensor delta, at::Tensor gamma, at::Tensor beta,
    double eps, at::Tensor mix6, at::Tensor cache_indices, at::Tensor conv) {
  return add_ln_shift_impl(x, delta, gamma, beta, eps, mix6, cache_indices,
                           conv, 6);
}

std::tuple<at::Tensor, at::Tensor> add_ln_shift1(
    at::Tensor x, at::Tensor delta, at::Tensor gamma, at::Tensor beta,
    double eps, at::Tensor x_k, at::Tensor cache_indices, at::Tensor conv) {
  auto r = add_ln_shift_impl(x, delta, gamma, beta, eps, x_k, cache_indices,
                             conv, 1);
  return {std::get<0>(r), std::get<1>(r).squeeze(0)};  // [1,T,N] -> [T,N]
}

at::Tensor gn_gatecorr(at::Tensor o, at::Tensor r, at::Tensor k, at::Tensor rk,
                       at::Tensor v, at::Tensor g, at::Tensor gamma,
                       at::Tensor beta, double eps, int64_t nh) {
  const int64_t T = o.size(0);
  const int64_t H = o.size(1);
  TORCH_CHECK(o.is_cuda() && o.scalar_type() == at::kHalf, "gn_gatecorr: o CUDA fp16");
  TORCH_CHECK(nh > 0 && H % nh == 0, "gn_gatecorr: H % nh == 0");
  const int64_t D = H / nh;
  TORCH_CHECK(D <= 64, "gn_gatecorr: head_dim <= 64 (sum tree is 2x32 lanes)");
  for (const auto& t : {r, k, v, g}) {
    TORCH_CHECK(t.scalar_type() == at::kHalf && t.numel() == T * H &&
                    t.is_contiguous(),
                "gn_gatecorr: r/k/v/g fp16 [T,H] contiguous");
  }
  TORCH_CHECK(rk.scalar_type() == at::kHalf && rk.numel() == H && rk.is_contiguous(),
              "gn_gatecorr: r_k fp16 [H]");
  TORCH_CHECK(gamma.scalar_type() == at::kHalf && gamma.numel() == H &&
                  beta.scalar_type() == at::kHalf && beta.numel() == H &&
                  gamma.is_contiguous() && beta.is_contiguous(),
              "gn_gatecorr: affine fp16 [H]");
  TORCH_CHECK(o.is_contiguous(), "gn_gatecorr: o contiguous");
  auto out = at::empty_like(o);
  if (T == 0) return out;
  // torch rounds the GroupNorm eps through the input dtype (fp16) first.
  const float eps_h = __half2float(__float2half_rn(static_cast<float>(eps)));
  auto stream = at::cuda::getCurrentCUDAStream();
  rwkv7_launch_maybe_pdl(rwkv7_pdl_enabled("ln"), gn_gatecorr_kernel,
      dim3(static_cast<unsigned>(T * nh)), dim3(32), 0, stream.stream(),
      static_cast<int>(D), eps_h, static_cast<int>(nh),
      static_cast<const dtype*>(o.data_ptr<dtype>()),
      static_cast<const dtype*>(r.data_ptr<dtype>()),
      static_cast<const dtype*>(k.data_ptr<dtype>()),
      static_cast<const dtype*>(rk.data_ptr<dtype>()),
      static_cast<const dtype*>(v.data_ptr<dtype>()),
      static_cast<const dtype*>(g.data_ptr<dtype>()),
      static_cast<const dtype*>(gamma.data_ptr<dtype>()),
      static_cast<const dtype*>(beta.data_ptr<dtype>()), out.data_ptr<dtype>());
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  return out;
}

TORCH_LIBRARY(rwkv7_ln, m) {
  m.def("add_ln(Tensor x, Tensor delta, Tensor gamma, Tensor beta, float eps) -> (Tensor, Tensor)");
  m.def(
      "gn_gatecorr(Tensor o, Tensor r, Tensor k, Tensor rk, Tensor v, Tensor g, "
      "Tensor gamma, Tensor beta, float eps, int nh) -> Tensor");
  m.def("relu_sq(Tensor x) -> Tensor");
  m.def(
      "vres_gates(Tensor wl, Tensor al, Tensor? vl, Tensor v, Tensor? vf, "
      "float inv_sqrt_e) -> (Tensor, Tensor, Tensor)");
  // F0066: conv is mutated in-place (token-shift scatter) — declare (a!) so
  // functionalization/compile passes see the write (same as rwkv7_glue).
  m.def(
      "add_ln_shift6(Tensor x, Tensor delta, Tensor gamma, Tensor beta, "
      "float eps, Tensor mix6, Tensor cache_indices, Tensor(a!) conv) "
      "-> (Tensor, Tensor)");
  m.def(
      "add_ln_shift1(Tensor x, Tensor delta, Tensor gamma, Tensor beta, "
      "float eps, Tensor x_k, Tensor cache_indices, Tensor(a!) conv) "
      "-> (Tensor, Tensor)");
}
TORCH_LIBRARY_IMPL(rwkv7_ln, CUDA, m) {
  m.impl("add_ln", &add_ln);
  m.impl("gn_gatecorr", &gn_gatecorr);
  m.impl("relu_sq", &relu_sq);
  m.impl("vres_gates", &vres_gates);
  m.impl("add_ln_shift6", &add_ln_shift6);
  m.impl("add_ln_shift1", &add_ln_shift1);
}
