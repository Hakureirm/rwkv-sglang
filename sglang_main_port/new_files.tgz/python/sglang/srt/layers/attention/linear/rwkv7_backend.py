# Copyright 2025-2026 SGLang Team
# Licensed under the Apache License, Version 2.0 (the "License");
"""RWKV-7 (Goose) linear-attention backend for sglang.

Unlike GDN, the RWKV-7 model module does ALL projections / LoRAs / gating in plain
torch and hands the backend already-projected per-head tensors. This backend owns
the two pieces of recurrent state in the MambaPool:

  * conv[0] / conv[1] : the two width-2 (prev-token) token-shift states
                        (attn / ffn), shape (size+1, hidden, 1), fp32.
  * temporal          : the WKV recurrent state S, shape (size+1, H, K, V), fp32.

The model calls `token_shift(...)` (before projections) and `recurrence(...)`
(after projections) directly on this backend instance, which it obtains via
`forward_batch.attn_backend.linear_attn_backend`. We therefore bypass the
RadixLinearAttention / HybridLinearAttnBackend.forward dispatch (whose fixed
mixed_qkv/a/b signature does not fit RWKV-7's r/w/k/v/kk/a). `init_forward_metadata`
is still driven through HybridLinearAttnBackend, so `self.forward_metadata`
(query_start_loc + mamba_cache_indices) is populated normally.
"""

import os
from typing import Optional

import torch

from sglang.srt.layers.attention.base_attn_backend import AttentionBackend
from sglang.srt.layers.attention.hybrid_linear_attn_backend import (
    MambaAttnBackendBase,
)

# The WKV recurrence is a self-contained triton kernel for BOTH the decode
# (T==1) AND the extend/prefill (packed varlen via cu_seqlens) path, with no
# dependency on the flash-linear-attention package.
from sglang.srt.layers.attention.rwkv7_kernels import wkv_recurrent
from sglang.srt.model_executor.forward_batch_info import ForwardBatch
from sglang.srt.model_executor.model_runner import ModelRunner

# R2 fused paged token-shift + lerp glue. Without it the shift is a torch
# gather/scatter pair per block (index + index_put_ + copies), which on the
# 7.2B decode step costs ~880 us — the whole gap between this line and the
# 0.5.10 flagship (F0078).
_FUSED_GLUE = os.environ.get("RWKV_FUSED_GLUE", "0") == "1"


class Rwkv7NoOpFullAttnBackend(AttentionBackend):
    """A trivial full-attention backend for the all-linear RWKV-7 case.

    RWKV-7 has ZERO full-attention layers, so HybridLinearAttnBackend never routes
    any layer to the full backend. But it still calls `init_forward_metadata` (and a
    few cuda-graph hooks) on the full backend each step. Real backends
    (triton/flashinfer) either probe the empty full KV pool at construction or reject
    fp32 planning, so we substitute this no-op instead.
    """

    # HybridLinearAttnBackend (sglang main) copies these off the full backend at
    # construction; there is no full-attn KV pool here, and the req/token pools
    # come from the runner when one is given.
    token_to_kv_pool = None
    req_to_token_pool = None
    needs_cpu_seq_lens = False

    def __init__(self, model_runner: Optional[ModelRunner] = None):
        if model_runner is not None:
            self.req_to_token_pool = model_runner.req_to_token_pool
            self.token_to_kv_pool = getattr(model_runner, "token_to_kv_pool", None)
            self.max_context_len = model_runner.model_config.context_len

    def init_forward_metadata(self, forward_batch: ForwardBatch):
        pass

    def init_cuda_graph_state(self, max_bs: int, max_num_tokens: int):
        pass

    def init_cpu_graph_state(self, *args, **kwargs):
        pass

    def init_forward_metadata_capture_cpu_graph(self, *args, **kwargs):
        pass

    def get_cuda_graph_seq_len_fill_value(self):
        return 1

    def get_cpu_graph_seq_len_fill_value(self):
        return 1

    def forward_decode(self, *args, **kwargs):
        raise NotImplementedError("RWKV-7 has no full-attention layers.")

    def forward_extend(self, *args, **kwargs):
        raise NotImplementedError("RWKV-7 has no full-attention layers.")


class Rwkv7AttnBackend(MambaAttnBackendBase):
    """Linear-attention backend for RWKV-7.

    Both the decode and the extend/prefill paths run through the same FLA-free
    `wkv_recurrent` triton kernel (exact, ~1e-6 vs the numpy oracle). scale=1.0 to
    match the numpy oracle, which applies no scaling to r before GroupNorm.
    """

    def __init__(self, model_runner: ModelRunner):
        super().__init__(model_runner)
        # Base-class field (tuple[int, int]); RWKV-7's token-shift window is
        # (hidden, conv_kernel-1=1). The base reads [-1] as the conv window length.
        self.conv_states_shape = tuple(
            model_runner.req_to_token_pool.mamba_pool.mamba_cache.conv[0].shape[-2:]
        )
        self.scale = 1.0
        # Verify-mode (spec-decode TARGET_VERIFY) per-pool-slot lookup used by
        # the K-step intermediate-state capture in token_shift/recurrence below;
        # GDN/KDA set up the same thing (gdn_backend.py). Identity over slot ids.
        self.verify_intermediate_state_indices = torch.arange(
            self.req_to_token_pool.size, dtype=torch.int32, device=model_runner.device
        )

    def _fused_glue_conv(self, layer_id, conv_idx, normed, forward_batch):
        """Shared eligibility check for the fused shift+lerp glue (R2). Returns
        (conv, cache_indices) when eligible (RWKV_FUSED_GLUE, decode, fp16 normed,
        fp32 contiguous conv, int32 contiguous cache_indices, glue built), else
        None so the caller falls back to token_shift + fused_lerp*.

        The kernel takes the raw cache_indices, pad slots (-1) included: it is
        byte-gated on the pad-slot and duplicate-index cases (bench/test_glue.py),
        unlike torch advanced indexing, which is why token_shift below has to
        clamp and this does not."""
        if not (
            _FUSED_GLUE
            and forward_batch.forward_mode.is_decode_or_idle()
            and normed.dtype == torch.float16
        ):
            return None
        conv = self.req_to_token_pool.mamba2_layer_cache(layer_id).conv[conv_idx]
        if conv.dtype != torch.float32 or not conv.is_contiguous():
            return None
        ci = self.forward_metadata.mamba_cache_indices
        if ci.dtype != torch.int32 or not ci.is_contiguous():
            return None
        from sglang.srt.layers.attention.rwkv7_kernels import glue

        if not glue.available():
            return None
        return conv, ci

    def try_fused_shift_lerp6(self, x, layer_id, conv_idx, mix6_buf, forward_batch):
        """Fused paged token-shift + 6-way lerp -> lp6[6,T,H], or None (fallback).
        Byte-exact vs token_shift + fused_lerp6 (bench/test_glue.py).

        This used to be an unconditional `return None` stub: the backend was
        ported without the glue, and the model's call site treats None as the
        documented fallback, so the line ran correct-but-slow with nothing
        announcing it. The profile is what surfaced it — 0.5.10 issues
        shift_lerp6/shift_lerp1 once per block, this line issued a torch
        index + index_put_ + two copies instead (F0078)."""
        e = self._fused_glue_conv(layer_id, conv_idx, x, forward_batch)
        if e is None or mix6_buf.dtype != torch.float16:
            return None
        conv, ci = e
        from sglang.srt.layers.attention.rwkv7_kernels import glue

        return glue.shift_lerp6(x.contiguous(), mix6_buf, ci, conv)

    def try_fused_shift_lerp1(self, x, layer_id, conv_idx, x_k, forward_batch):
        """Fused paged token-shift + 1-way lerp -> xk[T,H], or None (fallback).
        The FFN (channel-mix) counterpart of try_fused_shift_lerp6."""
        e = self._fused_glue_conv(layer_id, conv_idx, x, forward_batch)
        if e is None or x_k.dtype != torch.float16:
            return None
        conv, ci = e
        from sglang.srt.layers.attention.rwkv7_kernels import glue

        return glue.shift_lerp1(
            x.contiguous(), x_k.reshape(-1).contiguous(), ci, conv
        )

    def try_fused_addln_shift6(self, x, delta, ln, layer_id, conv_idx, mix6,
                               forward_batch):
        """add_ln + token-shift + 6-way lerp in one launch -> (x, lp6), or None.

        F0066a: a net regression as shipped (the J=6 kernel's single 512-thread
        block cannot match the composition's 16-block-parallel store), so
        `RWKV_FUSED_ADDLN_SHIFT` is default OFF and nothing in `serve.sh` sets it.
        It is here because the finding says the data supports arming J=1 later and
        that the path was kept in-tree rather than deleted -- and for three commits
        it was not: the call sites at `models/rwkv7.py` went in with `134259c`
        while this half did not, so setting the documented flag raised
        AttributeError instead of running the path it names. Same shape as the
        `try_fused_shift_lerp6` stub above, one notch louder: that one fell back
        silently, this one did not fall back at all."""
        e = self._fused_glue_conv(layer_id, conv_idx, x, forward_batch)
        if e is None or mix6.dtype != torch.float16:
            return None
        if delta.dtype != torch.float16 or ln.weight.dtype != torch.float16:
            return None
        if x.shape[-1] > 4096 or (x.shape[-1] % 4) != 0:
            return None
        conv, ci = e
        from sglang.srt.layers.attention.rwkv7_kernels import ln_fused

        if not ln_fused.available():
            return None
        return ln_fused.add_ln_shift6(
            x.contiguous(), delta.contiguous(), ln, mix6, ci, conv
        )

    def try_fused_addln_shift1(self, x, delta, ln, layer_id, conv_idx, x_k,
                               forward_batch):
        """The FFN (channel-mix) counterpart of try_fused_addln_shift6.

        This is the `J=1` arm, which the F0066a data has at parity on 7.2B
        (5.48us vs 5.43 composed) and ahead on 1.5B (3.69 vs 4.29) -- i.e. the one
        the finding says is worth arming on its own. It is gated behind the same
        default-OFF flag as the J=6 arm."""
        e = self._fused_glue_conv(layer_id, conv_idx, x, forward_batch)
        if e is None or x_k.dtype != torch.float16:
            return None
        if delta.dtype != torch.float16 or ln.weight.dtype != torch.float16:
            return None
        if x.shape[-1] > 4096 or (x.shape[-1] % 4) != 0:
            return None
        conv, ci = e
        from sglang.srt.layers.attention.rwkv7_kernels import ln_fused

        if not ln_fused.available():
            return None
        return ln_fused.add_ln_shift1(
            x.contiguous(), delta.contiguous(), ln,
            x_k.reshape(-1).contiguous(), ci, conv
        )

    # ---- token-shift (width-2 causal shift via the conv state) ----
    def token_shift(
        self,
        x: torch.Tensor,
        layer_id: int,
        conv_idx: int,
        forward_batch: ForwardBatch,
    ) -> torch.Tensor:
        """Return the previous-token hidden state for each position in x.

        x: [num_tokens, hidden] (post attn_norm / ffn_norm). Updates the stored
        conv state with the last token of each sequence for the next step.
        """
        cache = self.req_to_token_pool.mamba2_layer_cache(layer_id)
        conv = cache.conv[conv_idx]  # [size+1, hidden, 1]
        md = self.forward_metadata
        cache_indices = md.mamba_cache_indices

        if forward_batch.forward_mode.is_decode_or_idle():
            # one token per request: shifted = stored prev; store current.
            # Padded cuda-graph replay fills the tail of mamba_cache_indices with
            # PAD_SLOT_ID = -1; torch advanced indexing would WRAP -1 to row `size`
            # (an allocatable live slot) and corrupt a real request's shift state.
            # Route pads to row 0, the MambaPool's reserved never-allocated slot
            # (free_slots = arange(1, size+1)); pad outputs are discarded anyway.
            safe_idx = torch.clamp_min(cache_indices, 0)
            # advanced indexing already materializes a fresh tensor (no aliasing)
            prev = conv[safe_idx, :, 0]  # [n, hidden]
            conv[safe_idx, :, 0] = x.to(conv.dtype)
            return prev.to(x.dtype)

        if forward_batch.forward_mode.is_target_verify():
            # K draft-token chain (topk=1 -> no branching, RwkvSpecWorker):
            # candidates are [t_last, d_0, .., d_{K-2}] per request, packed
            # request-major. Reuse the exact decode single-step update K times
            # (same kernel call as the plain baseline at every step -> bit-
            # identical by construction, no batched-shape reduction-order
            # divergence -- sidesteps the F0031 class of near-tie flip).
            # Derived from batch_size (not spec_info.draft_token_num): cuda-
            # graph capture builds a synthetic TARGET_VERIFY-shaped dummy batch
            # with spec_info=None (it only knows the token-per-bs count, not a
            # real NgramVerifyInput), so spec_info must not be load-bearing here.
            bs = forward_batch.batch_size
            K = x.shape[0] // bs
            x_r = x.view(bs, K, -1)
            safe_idx = torch.clamp_min(cache_indices[:bs], 0)  # pool slots (persistent conv[])
            # intermediate_conv_window is indexed by REQUEST ORDINAL (0..bs-1)
            # within this batch, NOT by pool slot -- confirmed against
            # _fused_conv_window_scatter_with_mask_kernel (src_idx = pid_req)
            # and GDN's own `verify_intermediate_state_indices[:batch_size]`
            # (arange(pool.size)[:batch_size] == arange(batch_size), not an
            # identity-over-pool-slots as the name suggests at a glance).
            req_pos = torch.arange(bs, device=x.device)
            shifted = torch.empty_like(x_r)
            shifted[:, 0] = conv[safe_idx, :, 0].to(x.dtype)
            if K > 1:
                shifted[:, 1:] = x_r[:, :-1]
            # Per-step intermediate snapshot: step t's entry is "what the
            # persistent state should hold if exactly t+1 positions (0..t) are
            # accepted" -- i.e. token t's own (post-shift-input) value, since
            # token_shift's job is "store the current token for the next
            # shift". update_mamba_state_after_mtp_verify later scatters the
            # right step back into `conv` based on the real accept length.
            interm_conv = cache.intermediate_conv_window[conv_idx]  # [size+1, K, hidden, 1]
            # First K slots only: the buffer's second dim is the SERVER
            # capacity (speculative_num_draft_tokens); an adaptive round may
            # run a smaller chain, and the commit scatter only ever reads
            # step < accept <= K.
            interm_conv[req_pos, :K, :, 0] = x_r.to(interm_conv.dtype)
            # Persistent state: provisionally advance as if all K accepted;
            # the scatter above corrects it down to the real accept length.
            conv[safe_idx, :, 0] = x_r[:, -1].to(conv.dtype)
            return shifted.reshape(x.shape[0], -1)

        # extend (packed B=1, varlen via query_start_loc)
        qsl = md.query_start_loc.to(torch.long)
        starts = qsl[:-1]
        ends = qsl[1:]
        shifted = torch.empty_like(x)
        if x.shape[0] > 1:
            shifted[1:] = x[:-1]
        # Same pad convention as the decode path: route PAD_SLOT_ID = -1 to the
        # pool's reserved row 0. Fresh sequences' slots are zeroed upstream on
        # the forward stream (`mamba_needs_clear` is set at slot alloc,
        # collected in prepare_for_extend, and cleared by the ModelRunner
        # before any layer reads the pool), so this backend only handles pads.
        safe_idx = torch.clamp_min(cache_indices, 0)
        # first token of each sequence reads the stored prev-token (0 for fresh
        # reqs; the correct carry-in for chunked prefill / prefix continuation).
        shifted[starts] = conv[safe_idx, :, 0].to(x.dtype)
        # store last token of each sequence for the next chunk / decode.
        conv[safe_idx, :, 0] = x[ends - 1].to(conv.dtype)
        return shifted

    # ---- WKV recurrence (decode + extend both -> the wkv_recurrent kernel) ----
    def recurrence(
        self,
        r: torch.Tensor,
        w: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        kk: torch.Tensor,
        a: torch.Tensor,
        layer_id: int,
        forward_batch: ForwardBatch,
    ) -> torch.Tensor:
        """r,w,k,kk,a: [num_tokens, H, K]; v: [num_tokens, H, V]. Returns [num_tokens, H, V]."""
        cache = self.req_to_token_pool.mamba2_layer_cache(layer_id)
        temporal = cache.temporal  # [size+1, H, K, V] fp32
        md = self.forward_metadata
        cache_indices = md.mamba_cache_indices

        if forward_batch.forward_mode.is_decode_or_idle():
            # [bs, H, *] -> [bs, 1, H, *]
            r4 = r.unsqueeze(1).contiguous()
            w4 = w.unsqueeze(1).contiguous()
            k4 = k.unsqueeze(1).contiguous()
            v4 = v.unsqueeze(1).contiguous()
            kk4 = kk.unsqueeze(1).contiguous()
            a4 = a.unsqueeze(1).contiguous()
            # In-place indexed state: the kernel reads/writes temporal[cache_indices]
            # directly (skips the gather+scatter copies; ~3x less state traffic at large
            # bsz). Same reduction math + bits -> greedy decoding stays token-exact.
            o, _ = wkv_recurrent(
                r4,
                w4,
                k4,
                v4,
                kk4,
                a4,
                scale=self.scale,
                state_pool=temporal,
                cache_indices=cache_indices,
            )
            return o.squeeze(1)  # [bs, H, V]

        if forward_batch.forward_mode.is_target_verify():
            # Mirror token_shift's is_target_verify branch: K sequential calls
            # to the SAME in-place indexed decode kernel (one chain position
            # per call, batched across requests), capturing each step's
            # resulting state into intermediate_ssm for later selective
            # commit. Chaining the decode kernel K times, rather than one
            # batched extend-shaped call, is what makes this bit-identical to
            # the M=1 baseline (see the token_shift comment above).
            # Derived from batch_size, not spec_info -- see token_shift's
            # identical comment (cuda-graph capture's dummy batch has no
            # real spec_info to read draft_token_num off).
            bs = forward_batch.batch_size
            K = r.shape[0] // bs
            H, Kd, V = r.shape[-2], r.shape[-1], v.shape[-1]
            r_r, w_r, k_r, kk_r, a_r = (
                t.view(bs, K, H, Kd) for t in (r, w, k, kk, a)
            )
            v_r = v.view(bs, K, H, V)
            safe_idx = torch.clamp_min(cache_indices[:bs], 0)  # pool slots (persistent temporal[])
            # intermediate_ssm is indexed by REQUEST ORDINAL (0..bs-1), not by
            # pool slot -- see token_shift's identical comment/reasoning
            # (confirmed against _fused_mamba_state_scatter_with_mask_kernel's
            # `src_idx = pid_req`).
            req_pos = torch.arange(bs, device=r.device)
            interm_ssm = cache.intermediate_ssm  # [size+1, K, H, Kd, V]
            out = torch.empty(bs, K, H, V, dtype=v.dtype, device=v.device)
            for step in range(K):
                o, _ = wkv_recurrent(
                    r_r[:, step].unsqueeze(1).contiguous(),
                    w_r[:, step].unsqueeze(1).contiguous(),
                    k_r[:, step].unsqueeze(1).contiguous(),
                    v_r[:, step].unsqueeze(1).contiguous(),
                    kk_r[:, step].unsqueeze(1).contiguous(),
                    a_r[:, step].unsqueeze(1).contiguous(),
                    scale=self.scale,
                    state_pool=temporal,
                    cache_indices=cache_indices[:bs],
                )
                out[:, step] = o.squeeze(1)
                interm_ssm[req_pos, step] = temporal[safe_idx]
            return out.reshape(bs * K, H, V)

        # extend: packed B=1, varlen -> the same recurrent triton kernel.
        # Same pad convention as token_shift (fresh-slot zeroing likewise
        # happens upstream before the layers run).
        safe_idx = torch.clamp_min(cache_indices, 0)
        init_state = temporal[safe_idx].contiguous().float()  # [N, H, K, V]
        cu = md.query_start_loc.to(torch.int64)
        r1 = r.unsqueeze(0).contiguous()
        w1 = w.unsqueeze(0).contiguous()
        k1 = k.unsqueeze(0).contiguous()
        v1 = v.unsqueeze(0).contiguous()
        kk1 = kk.unsqueeze(0).contiguous()
        a1 = a.unsqueeze(0).contiguous()
        o, final_state = wkv_recurrent(
            r1,
            w1,
            k1,
            v1,
            kk1,
            a1,
            scale=self.scale,
            initial_state=init_state,
            output_final_state=True,
            cu_seqlens=cu,
        )
        temporal[safe_idx] = final_state.to(temporal.dtype)
        return o.squeeze(0)  # [total_T, H, V]

    # The model calls token_shift/recurrence directly; these are not used.
    def forward_decode(self, *args, **kwargs):
        raise NotImplementedError(
            "Rwkv7AttnBackend.recurrence/token_shift are called directly by the model."
        )

    def forward_extend(self, *args, **kwargs):
        raise NotImplementedError(
            "Rwkv7AttnBackend.recurrence/token_shift are called directly by the model."
        )
